class Date:
    def __init__(self, year: int, month: int, day: int) -> str:

        self.year = year
        self.month = month
        self.day = day

        self.validation_date()

    def validation_date(self):

        if str(self.year).isalpha():
            raise DateTimeErrorException('year', self.year, 'an integer')
        elif 0 < int(self.year) < 9999:
            pass
        else:
            raise DateTimeErrorException('year', self.year, 'between 0 and 9999')

        if str(self.month).isalpha():
            raise DateTimeErrorException('month', self.month, 'an integer')
        elif 1 <= int(self.month) <= 12:

            if int(self.month) in (4, 6, 9, 11):
                if str(self.day).isalpha():
                    raise DateTimeErrorException('day', self.day, 'an integer')
                elif 1 <= int(self.day) <= 30:
                    pass
                else:
                    raise DateTimeErrorException('day', self.day, 'between 1 and 30')

            elif int(self.month) == 2:

                if (int(self.year) % 4 == 0 and int(self.year) % 100 != 0) or int(self.year) % 400 == 0:

                    if str(self.day).isalpha():
                        raise DateTimeErrorException('day', self.day, 'an integer')
                    elif 1 <= int(self.day) <= 29:
                        pass
                    else:
                        raise DateTimeErrorException('day', self.day, 'between 1 and 29')

                else:

                    if str(self.day).isalpha():
                        raise DateTimeErrorException('day', self.day, 'an integer')
                    elif 1 <= int(self.day) <= 28:
                        pass
                    else:
                        raise DateTimeErrorException('day', self.day, 'between 1 and 28')
            else:
                
                if str(self.day).isalpha():
                    raise DateTimeErrorException('day', self.day, 'an integer')
                elif 1 <= int(self.day) <= 31:
                    pass
                else:
                    raise DateTimeErrorException('day', self.day, 'between 1 and 31')
        else:
            raise DateTimeErrorException('month', self.month, 'between 1 and 12')

    def __str__(self):
        return f'{int(self.year):04d}/{int(self.month):02d}/{int(self.day):02d}'


class DateTime(Date):
    def __init__(self, year: int, month: int, day: int, hour: int, minute: int, second: int) -> str:
        super().__init__(year, month, day)
        self.hour = hour
        self.minute = minute
        self.second = second

        self.validation_datetime()

    def validation_datetime(self):

        if str(self.hour).isalpha():
            raise DateTimeErrorException('hour', self.hour, 'an integer')
        elif 0 <= int(self.hour) <= 23:
            pass
        else:
            raise DateTimeErrorException('hour', self.hour, 'between 0 and 23')

        if str(self.minute).isalpha():
            raise DateTimeErrorException('minute', self.minute, 'an integer')
        elif 0 <= int(self.minute) <= 59:
            pass
        else:
            raise DateTimeErrorException('minute', self.minute, 'between 0 and 59')

        if str(self.second).isalpha():
            raise DateTimeErrorException('second', self.second, 'an integer')
        elif 0 <= int(self.second) <= 59:
            pass
        else:
            raise DateTimeErrorException('second', self.second, 'between 0 and 59')

    def __str__(self):
        return f'{super().__str__()} {int(self.hour):02d}:{int(self.minute):02d}:{int(self.second):02d}'


class DateTimeErrorException(Exception):
    def __init__(self, name, value, message, *args, **kwargs):
        super().__init__(args, kwargs)
        self.name = name
        self.value = value
        self.message = message

    def __str__(self):
        return f'Invalid value: "{self.value}" for {self.name}. It should be {self.message}'


try:
    date = Date(15359, 11, '5')
    print(date)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime('2100', 2, 29, 0, 4, 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime('2026', 4, 31, 0, 4, 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime(1568, 2, 29, 0, 4, 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime('efw', 2, 29, 0, 4, 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime(2321, 1, 15, 24, 4, 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime(2321, 1, 15, 15, 'bhvuyt', 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)

try:
    datetime = DateTime(2321, 1, 15, 17, 4, 6)
    print(datetime)
except DateTimeErrorException as e:
    print(e)
